using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class killself : MonoBehaviour
{

    public float timeToGraphic = 2;
    public float timeToLive = 2;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timeToLive -= Time.deltaTime;


        Color clr = this.GetComponent<SpriteRenderer>().color;
        clr.a = Mathf.Clamp(1- ((timeToGraphic - timeToLive) / timeToGraphic), 0, 1);
        this.GetComponent<SpriteRenderer>().color = clr;


        //print(timeToLive);
        if(timeToLive<0)
        {
            Destroy(this.gameObject);
        }
    }
}
