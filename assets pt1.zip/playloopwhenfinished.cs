using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[RequireComponent(typeof(AudioSource))]


public class playloopwhenfinished : MonoBehaviour
{
    public AudioSource loopsound;

    public AudioClip audio;
    private AudioSource audiosource;

    void Start()
    {
        // TODO DontDestroyOnLoad(this)

        audiosource = GetComponent<AudioSource>();
        audiosource.clip = audio;
        audiosource.Play();
        StartCoroutine(WaitForSound(audio));
        //while we fix the loopsound?
        //audiosource.loop = true;

        if(loopsound.isPlaying)
        {
            Destroy(this.gameObject);
        }
    }
    void Awake()
    {   
        GameObject[] obj = GameObject.FindGameObjectsWithTag("Music");
        if (obj.Length > 1) Destroy(this.gameObject);
        DontDestroyOnLoad(this.gameObject);
    }
    void Update()
    {
        
    }

    public IEnumerator WaitForSound(AudioClip Sound)
    {
        yield return new WaitUntil(() => audiosource.isPlaying == false);
        if (loopsound != null)
            loopsound.Play(); // TODO: or just use play delayed with delay of length of current thing?
    }

}
