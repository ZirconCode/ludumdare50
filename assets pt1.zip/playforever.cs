using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playforever : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void Awake()
    {
        GameObject[] obj = GameObject.FindGameObjectsWithTag("Music2");
        if (obj.Length > 1) Destroy(this.gameObject);
        DontDestroyOnLoad(this.gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
