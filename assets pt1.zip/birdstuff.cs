using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class birdstuff : MonoBehaviour //, IPointerClickHandler
{

    public bool frozen;
    public float speed = 0.5f;

    public AudioSource stupidstupidgunsound;

  //  public AudioSource gunshot;

    // Start is called before the first frame update
    void Start()
    {
        frozen = true;
    }

    // Update is called once per frame
    void Update()
    {
        if(frozen)
        {
            if(((this.transform.position - GameObject.FindGameObjectsWithTag("Player")[0].transform.position).magnitude) < 15)
            {
                frozen = false;
            }
        }
        else
        {
            transform.position = new Vector3(this.transform.position.x - (speed * Time.deltaTime), this.transform.position.y, this.transform.position.z);
        }
    }


    void OnMouseDown()
    {
         clicky();
      //  gunshot.Play();
        Destroy(this.gameObject);
    }

    public void clicky()
    {
        // OnClick code goes here ...
        //  print("clicky");
        Vector3 mousePos = UnityEngine.Input.mousePosition;
        Vector3 Worldpos = Camera.main.ScreenToWorldPoint(mousePos);
        Worldpos.z = 0;
        Instantiate(stupidstupidgunsound, Worldpos, Quaternion.identity);
    }

}
